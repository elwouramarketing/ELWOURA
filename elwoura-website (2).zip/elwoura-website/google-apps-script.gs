const SHEET_NAME = 'Inquiries';

function doPost(e) {
  try {
    const d = JSON.parse(e.postData.contents);
    const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME);
    if (!sheet) throw new Error('Tab named "Inquiries" not found');
    sheet.appendRow([new Date(), clean(d.name), clean(d.email), clean(d.phone), clean(d.business), clean(d.service), clean(d.message)]);
    return reply({ ok: true });
  } catch (err) {
    return reply({ ok: false, error: String(err) });
  }
}

function doGet() {
  return reply({ ok: true, status: 'Elwoura form endpoint is running' });
}

function clean(v) {
  v = String(v || '').trim();
  return /^[=+\-@]/.test(v) ? "'" + v : v;
}

function reply(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}
