ELWOURA WEBSITE
===============
1. Open index.html in your browser (double-click) to view the site.
2. To connect the contact form to Google Sheets:
   - Create a Google Sheet with a tab named "Inquiries"
     and headings: Time, Name, Email, Phone, Business, Service, Message
   - Extensions > Apps Script > paste google-apps-script.gs > Save
   - Deploy > New deployment > Web app > Execute as: Me, Access: Anyone
   - Copy the /exec URL
   - Open index.html in a text editor, find  const SHEET_URL=''
     and paste the URL between the quotes. Save.
3. Until SHEET_URL is filled in, the form opens WhatsApp with the inquiry.
4. Pages use hash addresses: #home #about #services #portfolio #contact
